#ifndef StreamingPipeline_h
#define StreamingPipeline_h
#include "Pipeline.h"

class StreamingPipeline : public Pipeline{
    protected:
        void extract() override;
        void load() override;
    public:
        using Pipeline::Pipeline;
};

#endif