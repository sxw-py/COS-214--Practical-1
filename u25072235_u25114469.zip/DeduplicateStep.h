#ifndef DeduplicateStep_h
#define DeduplicateStep_h
#include "Transformation.h"
class DeduplicateStep: public Transformation {
    public:
        using Transformation::Transformation; // FIX FOR: base class has parameterised constructor!
                                              //Derived class won't be able to be instantiate without compilation error

        Transformation* clone() const override; 
        vector<string> apply(vector<string> ) override;
};

#endif