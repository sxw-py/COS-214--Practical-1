#include "StreamingPipeline.h"

  void StreamingPipeline::extract(){
    if (factory == nullptr){
        return;
    }

     Connector* connector = factory->createConnector();
     records = connector->extract();
     cout << "Streaming extract: " << records.size() << " records\n";
     stage = 2;
     delete connector;
 }

  void StreamingPipeline::load(){
    cout << "Streaming load: " << records.size() << " records streamed\n";
    stage = 4;
 }