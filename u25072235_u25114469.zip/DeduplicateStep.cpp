#include "DeduplicateStep.h"

vector<string> DeduplicateStep::apply(vector<string> arr) {
    if (arr.empty()){
        return arr;
    }

    vector<string> trans{};
    trans.push_back(arr[0]);

    for (size_t i = 1; i < arr.size(); ++i) {
        if (arr[i] != arr[i-1]) 
            trans.push_back(arr[i]);
    }


return trans;

} 

Transformation* DeduplicateStep::clone() const{
    return new DeduplicateStep(*this);
}