#include "AggregateByRegionStep.h"

vector<string> AggregateByRegionStep::apply(vector<string> arr){
    string out = "COUNT=";
    out += to_string(arr.size());
    vector<string> trans{out};
    return trans;
}

Transformation* AggregateByRegionStep::clone() const{
    return new AggregateByRegionStep(*this);
}