#ifndef Transformation_h
#define Transformation_h
#include <iostream>
#include <vector>
#include <string>
#include <map>

using namespace std;

class Transformation{
    protected:
        string name;
    public:
        Transformation(string);
        virtual Transformation* clone() const = 0;
        virtual vector<string> apply(vector<string> ) = 0;
        string getName();
        virtual ~Transformation();

};



#endif