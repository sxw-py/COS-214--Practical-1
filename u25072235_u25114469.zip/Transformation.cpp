//Task 2 
#include "Transformation.h"

Transformation::Transformation(string name){
    this->name = name;
}

string Transformation::getName(){
    return name;
}


Transformation::~Transformation(){
   
}