#ifndef Pipeline_h
#define Pipeline_h
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include "ConnectorFactory.h"
#include "Transformation.h"
#include "RunCheckpoint.h"

using namespace std;


class Pipeline{
    protected:
        ConnectorFactory *factory;
        vector<Transformation*> steps;
        int stage;
        vector<string> records;
        void connect();
        virtual void extract() = 0;
        void transform();
        virtual void load() = 0;
    public:
        Pipeline(ConnectorFactory*);
        void run();
        void addStep(Transformation*);
        RunCheckpoint* createCheckpoint();
        void restore(RunCheckpoint*);
        virtual ~Pipeline();
    
};



#endif