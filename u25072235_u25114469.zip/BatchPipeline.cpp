#include "BatchPipeline.h"


 void BatchPipeline::extract(){
    if (factory == nullptr){
        return;
    }

     Connector* connector = factory->createConnector();
     records = connector->extract();
     cout << "Batch extract: " << records.size() << " records\n";
     stage = 2;
     delete connector;
 }

 void BatchPipeline::load(){
    cout << "Batch load: " << records.size() << " records written\n";
    stage = 4;
 }