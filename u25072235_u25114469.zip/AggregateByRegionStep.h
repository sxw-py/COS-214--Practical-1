#ifndef AggregateByRegionStep_h
#define AggregateByRegionStep_h
#include "Transformation.h"

class AggregateByRegionStep: public Transformation {
    public:
        using Transformation::Transformation; //Same fix as dedup
    
        Transformation* clone() const override; 
        vector<string> apply(vector<string> ) override;
};

#endif