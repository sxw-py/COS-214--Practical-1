#ifndef BatchPipeline_h
#define BatchPipeline_h
#include "Pipeline.h"

class BatchPipeline : public Pipeline{
    protected:
        void extract() override;
        void load() override;
    public:
        using Pipeline::Pipeline;
};




#endif